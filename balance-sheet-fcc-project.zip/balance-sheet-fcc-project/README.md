# Balance Sheet FCC Project

A Pen created on CodePen.io. Original URL: [https://codepen.io/rebeccapackarddesigns/pen/YzemeNg](https://codepen.io/rebeccapackarddesigns/pen/YzemeNg).

